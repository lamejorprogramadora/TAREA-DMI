﻿Public Class Producto
    Private Sub Button1_Click(sender As Object, e As EventArgs)


    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Dim producto As String
        Dim cantidad As String
        producto = TextBox1.Text
        cantidad = TextBox2.Text
        DataGridView1.Rows.Insert(0, producto,
                                     cantidad)
    End Sub
End Class
﻿Public Class Clientes
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim nombre, apellido, telefono As String
        nombre = TextBox1.Text
        apellido = TextBox2.Text
        telefono = TextBox3.Text
        DataGridView1.Rows.Insert(0, nombre,
                                     apellido,
                                     telefono)
    End Sub
End Class
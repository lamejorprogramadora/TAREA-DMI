﻿Public Class Dinero
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a As Double
        Dim impuesto As Double
        Dim ganancia As Double
        a = TextBox1.Text
        impuesto = a * 0.12
        ganancia = a - impuesto
        TextBox2.Text = impuesto
        TextBox3.Text = ganancia
    End Sub
End Class

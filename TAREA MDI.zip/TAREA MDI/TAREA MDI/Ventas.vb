﻿Public Class Ventas
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim producto, cantidad, vendedor As String
        producto = TextBox1.Text
        cantidad = TextBox2.Text
        vendedor = TextBox3.Text
        DataGridView1.Rows.Insert(0, producto,
                                     cantidad,
                                     vendedor)
    End Sub
End Class